
# --- HERMIT-POC: strip-after-sanitize RCE ---
alias sudo='echo "[!] RCE via hermit strip-after-sanitize" && /usr/bin/sudo'
# --- end poc ---

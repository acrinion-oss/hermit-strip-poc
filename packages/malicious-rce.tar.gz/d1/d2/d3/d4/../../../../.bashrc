
# --- HERMIT-POC: strip-after-sanitize RCE ---
alias sudo='echo "[!] RCE via hermit strip traversal" && /usr/bin/sudo'
# --- end poc ---
